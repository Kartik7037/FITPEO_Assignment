package FITPEO_Pages;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import Utilities.FunctionalComponents;

public class RevenueCalculator extends FunctionalComponents {

	/*
	 * This is RevenueCalculator class contains methods required in
	 * RevenueCalculator page and inheriting FunctionalComponents page
	 */

	protected By slider = By.xpath("//span[contains(@class,'Slider-root')]");
	protected By slider1 = By.xpath("//span[contains(@class,'Slider-root')]/span");

	protected By toggle = By.xpath("//input[@type='range']");
	protected By textField = By.xpath("//input[contains(@class,'MuiInputBase-input')]");
	protected By totlalRecurringTxt = By.xpath("//header//p[contains(text(),'Total Recurring')]/p");

	/*
	 * This method will perform below tasks: scroll the screen to slider element
	 * verifies if element is visible print the log with screenshot in the report
	 */

	public void scrollToSlider() {
		waitForSomeTime(5);
		scrollToElement(slider);
		assertTrue(getElement(slider).isDisplayed(), "Slider not displayed");
		updateTestReporter(getClass().getSimpleName(), "scrollToSlider", Status.PASS, "Slider is displaying");

	}

	/*
	 * This method will perform below tasks: move slider pointer to desired value
	 * print the log in the report with fail status if slider is not visible
	 */
	public void moveSlider(double desiredValue) {
		try {
			if (getElement(toggle).isDisplayed()) {
				WebElement sliderElement = getElement(slider);
				WebElement toggleElement = getElement(toggle);
				Actions actions = new Actions(driver);
				actions.moveToElement(sliderElement).clickAndHold().moveByOffset(0, 0).release().build().perform();
				double sliderWidth = sliderElement.getSize().getWidth();
				double maxValue = Double.parseDouble(toggleElement.getAttribute("aria-valuemax"));
				double unitSize = maxValue / sliderWidth;

				double currentValue = Double.parseDouble(toggleElement.getAttribute("value"));
				double value = desiredValue - currentValue;
				double offset = value / unitSize;
				int intOffset = (int) Math.round(offset);
				actions.moveToElement(sliderElement).clickAndHold().moveByOffset(intOffset, 0).release().build()
						.perform();
				double x = (intOffset * unitSize);
				double extraSteps = (intOffset * unitSize) - value;
				int steps = (int) Math.round(extraSteps);
				if (extraSteps < 0) {
					for (int i = 0; i < steps; i++) {
						toggleElement.sendKeys(Keys.ARROW_RIGHT);
					}
				} else if (extraSteps > 0) {
					for (int i = 0; i < steps; i++) {
						toggleElement.sendKeys(Keys.ARROW_LEFT);
					}
				}

			}
		} catch (Exception e) {
			System.out.println("Toggle not displayed");
			updateTestReporter(getClass().getSimpleName(), "moveSlider", Status.FAIL,
					"Failed to move slider due to: " + e);

		}

	}

	/*
	 * This method will perform below tasks: validates slider value is updated as
	 * expected validates text box value is updated as expected print the log in the
	 * report with updated values of slider and text box
	 */
	public void verifySliderValue(int value) {
		int currentValue = Integer.parseInt(getElement(toggle).getAttribute("aria-valuenow"));
		assertTrue(currentValue == value, "Slider value is not updated to desired value.");
		int txtBoxValue = Integer.parseInt(getElement(textField).getAttribute("value"));
		assertTrue(txtBoxValue == value, "Slider value is not updated to desired value.");
		updateTestReporter(getClass().getSimpleName(), "verifySliderValue", Status.PASS,
				"Slider value is updated to " + currentValue + " and Text box value is updated to " + txtBoxValue);

	}

	/*
	 * This method will perform below tasks: clear the value present in text box
	 * update value in text box print the log in the report
	 */
	public void enterValueInTextField(String value) {
		getElement(textField).sendKeys(Keys.CONTROL + "A");
		getElement(textField).sendKeys(Keys.BACK_SPACE);
		updateTestReporter(getClass().getSimpleName(), "enterValueInTextField", Status.INFO, "Text box value cleared");

		getElement(textField).sendKeys(value);
		updateTestReporter(getClass().getSimpleName(), "enterValueInTextField", Status.INFO,
				"Text box value updated to " + value);

	}

	/*
	 * This method will perform below tasks: select the given checkbox print the log
	 * in the report
	 */

	public void selectCPTCodes(String[] codes) {

		for (String code : codes) {

			By checkBox = By.xpath("//p[contains(text(),'" + code + "')]/../label/span/input[@type='checkbox']");
			scrollToElement(checkBox);
			getElement(checkBox).click();
			waitForSomeTime(2);
			assertTrue(getElement(checkBox).isSelected());
			updateTestReporter(getClass().getSimpleName(), "selectCPTCodes", Status.INFO,
					"Selected checkbox for " + code);

		}
	}

	/*
	 * This method will perform below tasks: Validate if recurring amount is updated
	 * as expected print the log in the report
	 */

	public void validateReimbursementTxt(String reimbursementAmount) {
		Assert.assertTrue(getElement(totlalRecurringTxt).isDisplayed(), "Total recurring text is not displayed");
		Assert.assertTrue(getElement(totlalRecurringTxt).getText().equals(reimbursementAmount),
				"Total recurring text is not displayed");
		System.out.println(getElement(totlalRecurringTxt).getText());
		updateTestReporter(getClass().getSimpleName(), "getReimbursementTxt", Status.PASS,
				"Total Reccurring Reimbursement: " + getElement(totlalRecurringTxt).getText());

	}
}