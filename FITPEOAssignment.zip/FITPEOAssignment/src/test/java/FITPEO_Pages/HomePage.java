package FITPEO_Pages;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;

import com.aventstack.extentreports.Status;

import Utilities.FunctionalComponents;

public class HomePage extends FunctionalComponents {

	/*
	 * This is HomePage class contains methods required in home page and inheriting
	 * FunctionalComponents page
	 */

	protected By revenueCalculatorBtn = By.xpath("//div[contains(text(),'Revenue Calculator')]");

	/*
	 * This method will help to launch the URL
	 */
	public void LaunchURL() {
		driver.get("https://www.fitpeo.com/");
	}

	/*
	 * This method verifies if expected URL is launched and print the log with
	 * screenshot in the report
	 */
	public void verifyURL(String URL) {
		waitForSomeTime(10);
		assertTrue(driver.getCurrentUrl().trim().equalsIgnoreCase(URL),
				"Unable to launch " + driver.getCurrentUrl().trim());
		updateTestReporter(getClass().getSimpleName(), "LaunchURL", Status.PASS, "URL Lunach successfully");

	}

	/*
	 * This method click on the revenue caluclator button present in homepage header
	 * and print the log with screenshot in the report
	 */
	public void clickRevenueCalculatorBtn() {
		Wait(revenueCalculatorBtn, 60);
		getElement(revenueCalculatorBtn).click();
		waitForSomeTime(10);
		updateTestReporter(getClass().getSimpleName(), "clickRevenueCalculatorBtn", Status.PASS,
				"Clicked on Revenue Calculator Button");

	}
}