package Utilities;

import java.io.File;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.Random;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.MediaEntityModelProvider;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import io.github.bonigarcia.wdm.WebDriverManager;

public class FunctionalComponents {

	/*
	 * This is Utility class which contains some commonly used methods
	 */

	public static WebDriver driver;
	public static String emailableReportPath;
	static String reportName;
	static String emailableReportName;

	protected String reportpath;
	public static String resultDirectory;
	public static ExtentReports report;
	public static ExtentHtmlReporter htmlreport = null;
	public int counter = 001;
	public static ExtentTest extentlogger = null;
	public static String CurrentDate;

	/*
	 * This method helps to launch new chrome driver and start extent report
	 */

	public WebDriver setupTest() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		createReport();
		return driver;
	}

	/*
	 * This method will wait for an element to get displayed in the given time
	 */

	public void Wait(By by, int time) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(time));
		wait.until(ExpectedConditions.visibilityOfElementLocated(by));
	}

	/*
	 * This method helps to find element using xpath
	 */
	public WebElement getElement(By by) {
		return driver.findElement(by);
	}

	/*
	 * This method helps to scroll to particular element in the web page if present
	 */

	public void scrollToElement(By by) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", getElement(by));
		js.executeScript("window.scrollBy(0,-450)", "");
	}

	/*
	 * This method implements given wait and pause execution for the given time
	 */
	public void waitForSomeTime(int time) {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(time));
	}

	/*
	 * This method waits till the time page is loading
	 */
	public void checkPageLoad(int time) {
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(time));
	}

	/*
	 * This method helps to create a new report
	 */
	public void createReport() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		CurrentDate = formatter.format(date).replace("/", "_").replace(":", "_").replace(" ", "_");

		reportpath = System.getProperty("user.dir") + "/RunResults/" + CurrentDate + "/ResultReport.html";

		System.out.println("Report::" + reportpath);
		if (report == null) {

			htmlreport = new ExtentHtmlReporter(reportpath);
			htmlreport.config().setTheme(Theme.DARK);
			report = new ExtentReports();
			report.attachReporter(htmlreport);
			htmlreport.start();
			report.flush();
			System.out.println(report);
			extentlogger = report.createTest("FitPeo Automation Assignment");
		}
	}

	/*
	 * This method helps to take the screenshot of execution
	 */
	public String getScreenshot() {
		String destination = "";
		try {
			TakesScreenshot ts = (TakesScreenshot) driver;
			Random rand = new Random();
			int randomInteger = rand.nextInt(100);
			File source = ts.getScreenshotAs(OutputType.FILE);
			destination = System.getProperty("user.dir") + "/RunResults/" + CurrentDate + "/ScreenShots/"
					+ randomInteger + counter + "_" + CurrentDate + ".png";
			counter++;
			File finalDestination = new File(destination);
			FileUtils.copyFile(source, finalDestination);
		} catch (Exception e) {
			System.out.println(e);

		}

		return destination;
	}

	/*
	 * This method logs the test steps in the report along with status and
	 * screenshot
	 */
	public void updateTestReporter(String pageName, String functionName, Status Status, String StepMessage) {
		try {
			String screenshotPath = getScreenshot();
			screenshotPath = screenshotPath.substring(screenshotPath.indexOf("ScreenShots"));
			MediaEntityModelProvider screenshot = MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath)
					.build();
			if (Status.equals(Status.PASS)) {
				extentlogger.log(Status.PASS, pageName + " : " + functionName + " : " + StepMessage, screenshot);

			} else if (Status.equals(Status.INFO)) {
				extentlogger.log(Status.INFO, pageName + " : " + functionName + " : " + StepMessage, screenshot);

			} else if (Status.equals(Status.FAIL)) {
				extentlogger.log(Status.FAIL, pageName + " : " + functionName + " : " + StepMessage, screenshot);
				report.flush();
				Assert.assertTrue(false);

			}
			report.flush();

		} catch (Exception e) {
			System.out.println("Error in getting screenshot");
		}
	}
}
