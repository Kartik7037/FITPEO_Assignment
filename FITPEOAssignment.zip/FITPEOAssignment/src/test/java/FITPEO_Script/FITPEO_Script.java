
package FITPEO_Script;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import FITPEO_Pages.HomePage;
import FITPEO_Pages.RevenueCalculator;
import Utilities.FunctionalComponents;

public class FITPEO_Script extends FunctionalComponents {

	/*
	 * This class is main script class containing BeforeTest, Test and AfterTest
	 * methods, and inheriting Functional components class
	 */

	/* TestData Required */
	String homePageURL = "https://www.fitpeo.com/";
	String[] codes = { "CPT-99091", "CPT-99453", "CPT-99454", "CPT-99474" };
	int initialSliderValue = 820;
	int updatedSliderValue = 560;
	String reimbursementAmount = "$110700";

	/*
	 * This method is calling setUp test method present in FunctionalComponents page
	 */
	@BeforeTest
	public void launchDriver() {
		setupTest();
	}

	/*
	 * This is main script method which is calling other methods present in HomPage
	 * and RevenueCalculator required to cover automation scenario
	 */
	@Test
	public void FitPeo_Automation_Assignment() {
		HomePage homePage = new HomePage();
		RevenueCalculator revenueCalculator = new RevenueCalculator();
		try {
			homePage.LaunchURL();
			homePage.verifyURL(homePageURL);
			homePage.clickRevenueCalculatorBtn();
			revenueCalculator.scrollToSlider();
			revenueCalculator.moveSlider(initialSliderValue);
			revenueCalculator.verifySliderValue(initialSliderValue);
			revenueCalculator.enterValueInTextField(String.valueOf(updatedSliderValue));
			revenueCalculator.verifySliderValue(updatedSliderValue);
			revenueCalculator.enterValueInTextField(String.valueOf(initialSliderValue));
			revenueCalculator.verifySliderValue(initialSliderValue);
			revenueCalculator.selectCPTCodes(codes);
			revenueCalculator.validateReimbursementTxt(reimbursementAmount);

		} catch (Exception e) {
			updateTestReporter(getClass().getSimpleName(), "Run script", Status.FAIL, "Test Failed due to: " + e);
		}
	}

	/*
	 * This method is runs after test and closes opened Chrome driver
	 */
	@AfterTest
	public void closeDriver() {
		driver.quit();
	}
}